const express = require('express');
const dl = express();
let api = require("./api.json");
let fix = api.messages.main


/* [Custom Api (Exemplo)]
console.log(api.custom.oi);
*/


function msg() {
    let msg2 = api.msg
    console.log(msg2);
}
msg() // @...(dl-server.msg) #Custom msg

    var proxy = require("http");

proxy.createServer(function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/plain'});
   response.end('Status Port: ' + api.stts + ' | Main Port: ' + api.port);
}).listen(api.stts);
console.log("Status Proxy Iniciado na porta: " + api.stts); // você pode alterarar isso


dl.use(express.static(__dirname + api.app.dir)); 
dl.use(function(req, res, next) {
  res.status(404).send(api.messages.error);
});

dl.listen(api.port, () => {
  console.log(fix + api.port);
}); 
                 
